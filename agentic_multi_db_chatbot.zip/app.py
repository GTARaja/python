import streamlit as st
from graph.agent_graph import run_agent

st.set_page_config(page_title="Enterprise Agentic Multi-DB AI")

st.title("🤖 Enterprise Agentic Multi-DB Chatbot")

user_input = st.chat_input("Ask your question...")

if user_input:
    st.chat_message("user").write(user_input)

    try:
        result = run_agent(user_input)

        st.chat_message("assistant").write(f"📊 Database Used: {result['db_type']}")
        st.chat_message("assistant").write(f"🧾 SQL Generated:\n```sql\n{result['sql']}\n```")
        st.chat_message("assistant").write(result["answer"])

    except Exception as e:
        st.error(str(e))