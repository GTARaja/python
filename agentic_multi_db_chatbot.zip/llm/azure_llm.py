from langchain_openai import AzureChatOpenAI
from config.settings import *

def get_llm():
    return AzureChatOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        azure_deployment=AZURE_OPENAI_DEPLOYMENT,
        openai_api_version=AZURE_OPENAI_API_VERSION,
        api_key=AZURE_OPENAI_KEY,
        temperature=0
    )