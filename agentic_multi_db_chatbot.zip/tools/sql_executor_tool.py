from database.mysql_connector import execute_mysql
from database.oracle_connector import execute_oracle

def execute_sql(db_type: str, query: str):
    if db_type == "MYSQL":
        return execute_mysql(query)
    return execute_oracle(query)