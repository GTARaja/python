def detect_database(user_query: str) -> str:
    if "emp" in user_query.lower():
        return "ORACLE"
    return "MYSQL"