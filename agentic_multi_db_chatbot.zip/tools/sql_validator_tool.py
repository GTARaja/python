def validate_sql(query: str) -> str:
    forbidden = ["DELETE", "DROP", "UPDATE", "INSERT"]
    for word in forbidden:
        if word in query.upper():
            raise Exception("Unsafe SQL detected.")
    return query