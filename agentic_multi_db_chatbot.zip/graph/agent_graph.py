from tools.db_router_tool import detect_database
from database.metadata_loader import load_metadata
from tools.sql_validator_tool import validate_sql
from tools.sql_executor_tool import execute_sql
from llm.azure_llm import get_llm

def run_agent(user_input: str):

    llm = get_llm()

    # 1 Route DB
    db_type = detect_database(user_input)

    # 2 Get schema
    schema = load_metadata(db_type)

    # 3 Generate SQL
    sql_prompt = f"""
    Database Type: {db_type}
    Schema: {schema}
    Generate SQL query only for:
    {user_input}
    """

    sql_query = llm.invoke(sql_prompt).content

    # 4 Validate
    validated_query = validate_sql(sql_query)

    # 5 Execute
    result = execute_sql(db_type, validated_query)

    # 6 Convert to NL
    nl_prompt = f"""
    Convert this SQL result to business explanation:
    {result}
    """

    final_answer = llm.invoke(nl_prompt).content

    return {
        "db_type": db_type,
        "sql": validated_query,
        "answer": final_answer
    }