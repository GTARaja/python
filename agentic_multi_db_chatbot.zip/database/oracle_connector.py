import oracledb
from config.settings import ORACLE_CONFIG

def execute_oracle(query):
    conn = oracledb.connect(**ORACLE_CONFIG)
    cursor = conn.cursor()
    cursor.execute(query)
    rows = cursor.fetchall()
    columns = [col[0] for col in cursor.description]
    cursor.close()
    conn.close()
    return {"columns": columns, "rows": rows}