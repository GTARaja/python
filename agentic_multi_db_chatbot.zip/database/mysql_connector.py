import mysql.connector
from config.settings import MYSQL_CONFIG

def execute_mysql(query):
    conn = mysql.connector.connect(**MYSQL_CONFIG)
    cursor = conn.cursor()
    cursor.execute(query)
    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    cursor.close()
    conn.close()
    return {"columns": columns, "rows": rows}