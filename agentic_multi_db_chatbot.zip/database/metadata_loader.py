def load_metadata(db_type):
    if db_type == "MYSQL":
        return '''
        customers(id, name, city, created_at)
        orders(id, customer_id, amount, order_date)
        '''
    else:
        return '''
        EMP(empno, ename, deptno, sal)
        DEPT(deptno, dname, loc)
        '''