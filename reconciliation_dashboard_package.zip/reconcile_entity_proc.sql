
CREATE OR REPLACE PROCEDURE RECONCILE_ENTITY(p_metadata_id IN NUMBER) IS
    v_source_count NUMBER;
    v_target_count NUMBER;
    v_mismatch_count NUMBER;
    v_source_table VARCHAR2(100);
    v_target_table VARCHAR2(100);
BEGIN
    SELECT SOURCE_TABLE, TARGET_TABLE INTO v_source_table, v_target_table
    FROM XX_METADATA WHERE METADATA_ID = p_metadata_id;

    EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || v_source_table INTO v_source_count;
    EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || v_target_table INTO v_target_count;
    v_mismatch_count := ABS(v_source_count - v_target_count);

    INSERT INTO XX_RECON_DETAILS(
        METADATA_ID, SOURCE_COUNT, TARGET_COUNT, MISMATCH_COUNT)
    VALUES (p_metadata_id, v_source_count, v_target_count, v_mismatch_count);

    COMMIT;
END;
