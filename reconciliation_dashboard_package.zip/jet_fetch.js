
fetch('/ords/api/recon_summary')
  .then(response => response.json())
  .then(data => {
    this.summaryData = data.items;
  });
