
from llm import call_llm

def detect_database(user_query):
    system_prompt = '''
    Decide which database to use: MYSQL or ORACLE.
    Return only one word.
    '''
    return call_llm(system_prompt, user_query).strip().upper()
