
def load_metadata(db_type):
    if db_type == "MYSQL":
        return '''
        Tables:
        customers(id, name, city)
        orders(id, customer_id, amount)
        '''
    else:
        return '''
        Tables:
        EMP(empno, ename, deptno, sal)
        DEPT(deptno, dname, loc)
        '''
