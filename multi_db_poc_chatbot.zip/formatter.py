
from llm import call_llm
import pandas as pd

def format_response(columns, rows):
    df = pd.DataFrame(rows, columns=columns)
    system_prompt = "Convert SQL results into a natural language summary."
    return call_llm(system_prompt, df.to_string())
