
import streamlit as st
from db_router import detect_database
from metadata import load_metadata
from sql_generator import generate_sql
from executor import execute_query
from formatter import format_response

st.set_page_config(page_title="Multi DB PoC Chatbot")
st.title("🤖 Multi-DB Chatbot (Azure OpenAI PoC)")

user_input = st.chat_input("Ask your question...")

if user_input:
    st.chat_message("user").write(user_input)

    db_type = detect_database(user_input)
    metadata = load_metadata(db_type)
    sql_query = generate_sql(user_input, metadata, db_type)
    columns, rows = execute_query(db_type, sql_query)
    final_answer = format_response(columns, rows)

    st.chat_message("assistant").write(f"📊 Database Used: {db_type}")
    st.chat_message("assistant").write(f"🧾 Generated SQL:\n```sql\n{sql_query}\n```")
    st.chat_message("assistant").write(final_answer)
