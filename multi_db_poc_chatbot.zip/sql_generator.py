
from llm import call_llm

def generate_sql(user_query, metadata, db_type):
    system_prompt = f'''
    You are an SQL expert.
    Database Type: {db_type}
    Use this metadata:
    {metadata}
    Generate only SQL.
    '''
    return call_llm(system_prompt, user_query)
