Conversion Dashboard (Java Swing + Oracle)

1. Prerequisites:
   - Java SDK 8+
   - Oracle JDBC driver in classpath
   - Oracle database with XXCNV schema

2. Setup:
   - Edit DB connection string in ClientConfigPanel.java
   - Compile all Java files
   - Run MainApp.java

3. Features:
   - Client Config Screen (L1)
   - Conversion Cycle Dashboard (L2)
   - Entity Dashboard (L3)
   - Table Dashboard (L4)
   - Visual/summary panels for Mocks/Dress Rehearsals

4. To Enhance:
   - Add JFreeChart support for dashboards
   - Add edit/update/delete features
   - Add filters and dropdowns for navigation

5. SQL Tables: Refer to full DDL provided in prompt