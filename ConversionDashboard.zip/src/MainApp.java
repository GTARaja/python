import javax.swing.*;

public class MainApp extends JFrame {
    public MainApp() {
        setTitle("Conversion Dashboard");
        setSize(1000, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Client Config", new ClientConfigPanel());
        tabs.add("Main Dashboard", new MainDashboard());
        tabs.add("Conversion Cycle Dashboard", new ConversionCycleDashboard());
        tabs.add("Entity Dashboard", new EntityDashboard());
        tabs.add("Table Dashboard", new TableDashboard());

        add(tabs);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainApp::new);
    }
}