import javax.swing.*;
import java.awt.*;

public class ConversionCycleDashboard extends JPanel {
    public ConversionCycleDashboard() {
        setLayout(new BorderLayout());
        add(new JLabel("Conversion Cycle Dashboard - Mocks/Dress Rehearsals", JLabel.CENTER), BorderLayout.NORTH);
    }
}