import javax.swing.*;
import java.awt.*;

public class TableDashboard extends JPanel {
    public TableDashboard() {
        setLayout(new BorderLayout());
        add(new JLabel("Table Level Dashboard - Metrics from XX_CNV_TRACK_DET", JLabel.CENTER), BorderLayout.NORTH);
    }
}