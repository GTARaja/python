import javax.swing.*;
import java.awt.*;

public class EntityDashboard extends JPanel {
    public EntityDashboard() {
        setLayout(new BorderLayout());
        add(new JLabel("Entity Dashboard - Show all Entities for a selected Cycle", JLabel.CENTER), BorderLayout.NORTH);
    }
}