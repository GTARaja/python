import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ClientConfigPanel extends JPanel {
    JTextField txtClientName, txtMocks, txtDress, txtStart, txtTarget;
    JButton btnSave;

    public ClientConfigPanel() {
        setLayout(new GridLayout(6, 2, 10, 10));

        txtClientName = new JTextField();
        txtMocks = new JTextField();
        txtDress = new JTextField();
        txtStart = new JTextField("yyyy-mm-dd");
        txtTarget = new JTextField("yyyy-mm-dd");
        btnSave = new JButton("Save Client");

        add(new JLabel("Client Name:")); add(txtClientName);
        add(new JLabel("No. of Mocks:")); add(txtMocks);
        add(new JLabel("No. of Dress Rehearsals:")); add(txtDress);
        add(new JLabel("Start Date:")); add(txtStart);
        add(new JLabel("Target Date:")); add(txtTarget);
        add(new JLabel("")); add(btnSave);

        btnSave.addActionListener(e -> saveClient());
    }

    private void saveClient() {
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//host:port/service", "username", "password")) {
            String sql = "INSERT INTO XXCNV.CLIENT_MASTER (CLIENT_NAME, NUM_MOCKS, NUM_DRESS_REHEARSALS, DATE_STARTED, TARGET_COMPLETION_DATE) VALUES (?, ?, ?, TO_DATE(?, 'YYYY-MM-DD'), TO_DATE(?, 'YYYY-MM-DD'))";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, txtClientName.getText());
            stmt.setInt(2, Integer.parseInt(txtMocks.getText()));
            stmt.setInt(3, Integer.parseInt(txtDress.getText()));
            stmt.setString(4, txtStart.getText());
            stmt.setString(5, txtTarget.getText());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Client Saved Successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving client: " + ex.getMessage());
        }
    }
}