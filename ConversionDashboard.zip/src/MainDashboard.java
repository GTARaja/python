import javax.swing.*;
import java.awt.*;

public class MainDashboard extends JPanel {
    public MainDashboard() {
        setLayout(new BorderLayout());
        add(new JLabel("Main Dashboard - Summary of all Mocks/Dress Rehearsals", JLabel.CENTER), BorderLayout.NORTH);
    }
}